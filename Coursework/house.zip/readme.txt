Student: Stefania Calnuschi
E-mail: sc3u18@soton.ac.uk

Completed all the parts.
No extension attempted.
Used Java Doc comments.
The getRandomNumber functions are based on an algorithm found on internet.